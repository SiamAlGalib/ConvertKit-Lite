import re, json, html, shutil, sys
from pathlib import Path

P = Path(sys.argv[1] if len(sys.argv) > 1 else "tools/imagecompressor/index.html")
s = P.read_text(encoding="utf-8").replace("\r\n", "\n")
shutil.copy(P, "/tmp/imagecompressor.bak.html")

def rep(old, new, label, expect=1):
    global s
    n = s.count(old)
    if n != expect:
        raise SystemExit(f"STOP [{label}]: expected {expect} match(es), found {n}. Nothing was changed.")
    s = s.replace(old, new)

def span(start, end, new, label):
    global s
    if s.count(start) != 1 or s.count(end) != 1:
        raise SystemExit(f"STOP [{label}]: marker not found exactly once. Nothing was changed.")
    a = s.index(start); b = s.index(end) + len(end)
    if b <= a:
        raise SystemExit(f"STOP [{label}]: markers out of order. Nothing was changed.")
    s = s[:a] + new + s[b:]

# ---------- 1) Title, descriptions, H1, hero, trust row ----------
rep("Image Compressor — Reduce Image Size Free | ConvertKit Lite",
    "Image Compressor – Compress JPG, PNG &amp; WebP Online Free", "titles", 3)
rep("Compress and resize images online for free. Batch process many images at once with adjustable quality, right in your browser. Private, no sign-up.",
    "Compress image online free. Reduce JPG, PNG and WebP file size, set a target like 100KB, or batch compress in your browser. No sign-up, no watermark.",
    "descriptions", 3)
rep("Make images smaller in file size and dimensions in your browser. Private and free.",
    "Reduce image file size online for free. Compress JPG, PNG and WebP to a target size in your browser. Private, no sign-up.", "og description")
rep("<h1>Image Compressor &amp; <span>Resizer</span></h1>", "<h1>Image <span>Compressor</span></h1>", "h1")
rep("<p>Make images smaller in file size and dimensions. Works on many images at once, right in your browser.</p>",
    "<p>Compress images online for free and reduce image file size. Pick a quality level or a target size such as 100KB, and resize if you like. Works on many JPG, PNG and WebP images at once, right in your browser.</p>",
    "hero text")
rep("<div>No registration required</div><div>Secure &amp; private</div><div>Works on any device</div>",
    "<div>No registration required</div><div>No watermark</div><div>Secure &amp; private</div><div>Works on any device</div>", "trust row")

# ---------- 2) CSS ----------
rep(".features{width:min(760px,calc(100% - 32px));margin:22px auto 40px}",
    ".features{width:min(760px,calc(100% - 32px));margin:22px auto 40px}\n.trow{display:flex;gap:8px}.trow select{width:92px;flex:none}", "css")

# ---------- 3) Tool form: add 'Compress by' + target size ----------
PRESETS = [("20", "20 KB"), ("50", "50 KB"), ("100", "100 KB"), ("150", "150 KB"), ("200", "200 KB"),
           ("300", "300 KB"), ("500", "500 KB"), ("1024", "1 MB"), ("2048", "2 MB")]
opts = "".join(f'<option value="{v}"{" selected" if v == "100" else ""}>{t}</option>' for v, t in PRESETS)
rep('''<div>
<label for="q">Quality</label>
<div class="rowv"><span id="qv">80%</span></div>
<input type="range" id="q" min="10" max="100" value="80"/>
</div>
</div>
<div class="hint" id="qhint"></div>''',
f'''<div>
<label for="cmode">Compress by</label>
<select id="cmode"><option value="q">Quality level</option><option value="t">Target file size</option></select>
</div>
</div>
<div id="qBox">
<label for="q">Quality</label>
<div class="rowv"><span id="qv">80%</span></div>
<input type="range" id="q" min="10" max="100" value="80"/>
</div>
<div id="tBox" class="hide">
<div class="grid">
<div><label for="tpre">Target size (for each image)</label><select id="tpre">{opts}<option value="custom">Custom…</option></select></div>
<div id="tcBox" class="hide"><label for="tval">Custom size</label><div class="trow"><input type="number" id="tval" min="0.1" step="any" value="100"/><select id="tunit"><option value="1">KB</option><option value="1024">MB</option></select></div></div>
</div>
</div>
<div class="hint" id="qhint"></div>''', "form")

# ---------- 4) JavaScript ----------
rep("['q','rmode','fmt','pct','cw','ch','keep'].forEach(",
    "['q','rmode','fmt','pct','cw','ch','keep','cmode','tpre','tval','tunit'].forEach(", "listeners")

rep("""  $('q').disabled=f==='png';
  $('qhint').textContent=f==='png'?'PNG is lossless, so quality does not apply. Resize the image or choose WebP/JPG for a much smaller file.':'';""",
"""  const t=$('cmode').value==='t';
  $('qBox').classList.toggle('hide',t);
  $('tBox').classList.toggle('hide',!t);
  $('tcBox').classList.toggle('hide',$('tpre').value!=='custom');
  $('q').disabled=f==='png';
  $('qhint').textContent=t?'Each image is compressed to fit under the target: quality is lowered first, then the size in pixels if needed. PNG has no quality setting, so a PNG can only reach a target by being made smaller in pixels.':(f==='png'?'PNG is lossless, so quality does not apply. Resize the image, choose WebP/JPG, or use Target file size for a much smaller file.':'');""",
"uiSync")

rep("const toBlob=(c,t,q)=>new Promise(r=>c.toBlob(r,t,q));",
    "const toBlob=(c,t,q)=>new Promise(r=>c.toBlob(r,t,q));\n"
    "const targetBytes=()=>{const p=$('tpre').value;const kb=p==='custom'?Math.max(1,(+$('tval').value||0)*(+$('tunit').value)):+p;return Math.round(kb*1024)};",
    "targetBytes")

NEW_COMPRESS = r"""  nw=Math.max(1,nw);nh=Math.max(1,nh);
  const fmt=$('fmt').value;
  const type=fmt==='same'?(EXT[f.type]?f.type:'image/jpeg'):'image/'+fmt;
  const draw=async(sc,q)=>{
    const dw=Math.max(1,Math.round(nw*sc)),dh=Math.max(1,Math.round(nh*sc));
    const c=document.createElement('canvas');c.width=dw;c.height=dh;
    const x=c.getContext('2d');
    if(type==='image/jpeg'){x.fillStyle='#fff';x.fillRect(0,0,dw,dh)}
    x.imageSmoothingQuality='high';x.drawImage(img,0,0,dw,dh);
    const b=await toBlob(c,type,q);
    if(!b)throw new Error('encode');
    return{b,w:dw,h:dh};
  };
  const target=$('cmode').value==='t'?targetBytes():0;
  let blob,fw=nw,fh=nh,missed=false;
  if(target&&fmt==='same'&&EXT[f.type]&&nw===w&&nh===h&&f.size<=target){blob=f;fw=w;fh=h}
  else if(target){
    const lossy=type!=='image/png';
    let sc=1,best=null,last=null;
    for(let pass=0;pass<14&&!best;pass++){
      if(lossy){
        const lo=await draw(sc,.1);last=lo;
        if(lo.b.size<=target){
          best=lo;let a=.1,z=1;
          for(let k=0;k<7;k++){const m=(a+z)/2,r=await draw(sc,m);if(r.b.size<=target){best=r;a=m}else z=m}
        }else sc*=Math.max(.5,Math.min(.9,Math.sqrt(target/lo.b.size)*.95));
      }else{
        const r=await draw(sc,1);last=r;
        if(r.b.size<=target)best=r;else sc*=Math.max(.5,Math.min(.9,Math.sqrt(target/r.b.size)*.95));
      }
      if(!best&&last.w<=1&&last.h<=1)break;
    }
    missed=!best;const r=best||last;blob=r.b;fw=r.w;fh=r.h;
  }else{
    const r=await draw(1,+$('q').value/100);blob=r.b;fw=r.w;fh=r.h;
  }
  if(blob!==f&&fmt==='same'&&EXT[f.type]&&fw===w&&fh===h&&blob.size>=f.size){blob=f;missed=target?f.size>target:false}
  if(blob===f&&target)missed=f.size>target;
  const ext=EXT[blob.type]||EXT[type]||'jpg';
  const base=f.name.replace(/\.[^.]+$/,'');
  const url=await readURL(blob);
  return{name:base+(blob===f?'':'-compressed')+'.'+ext,blob,url,from:f.size,to:blob.size,dim:w+'×'+h,ndim:fw+'×'+fh,missed};"""
span("  nw=Math.max(1,nw);nh=Math.max(1,nh);", "ndim:nw+'×'+nh};", NEW_COMPRESS, "compress()")

rep("    try{r=await compress(files[i].f)}catch(e){files[i].bad=true}",
    "    $('status').textContent='Compressing '+(i+1)+' of '+files.length+'…';\n    try{r=await compress(files[i].f)}catch(e){files[i].bad=true}", "progress")
rep("  const bad=files.filter(x=>x.bad);\n  if(bad.length)$('err').textContent=",
    "  $('status').textContent='';\n  const miss=results.filter(r=>r&&r.missed);\n  if(miss.length)$('err').textContent='Could not get under the target for: '+miss.map(r=>r.name).join(', ')+'. Try a larger target.';\n  const bad=files.filter(x=>x.bad);\n  if(bad.length)$('err').textContent=(miss.length?$('err').textContent+' ':'')+",
    "run end")
rep("$('out').innerHTML='';$('summary').style.display='none';$('err').textContent='';refreshSel();",
    "$('out').innerHTML='';$('summary').style.display='none';$('err').textContent='';$('status').textContent='';refreshSel();", "clear")
rep("<strong>${esc(r.name)}</strong>", "<strong>${esc(r.name)}${r.missed?' · above target':''}</strong>", "render name")

# ---------- 5) How-to step, prose, tips ----------
rep("<p>Choose the output format and quality, and optionally resize by percentage or to a set width and height. Results update automatically.</p>",
    "<p>Choose the output format, then compress by quality level or by target file size such as 100KB. You can also resize by percentage or to a set width and height. Results update automatically.</p>", "step 2")

rep("    <li><b>Resize by percentage.</b>",
    "    <li><b>Target file size.</b> Choose Compress by, then Target file size, and pick 20 KB up to 2 MB or enter your own size. The tool finds a setting that fits each image under it (see the section below).</li>\n    <li><b>Resize by percentage.</b>",
    "bullet target")

NEW_PROSE = """<h2>How to compress an image to 100KB, 200KB or 1MB</h2>
  <p>Many forms, job portals and email systems set a maximum file size. Set <b>Compress by</b> to <b>Target file size</b> and choose a preset: 20, 50, 100, 150, 200, 300 or 500 KB, or 1 or 2 MB. For anything else choose Custom and type a size in KB or MB. Here, 1 KB is 1,024 bytes.</p>
  <ul>
    <li><b>JPG and WebP.</b> The tool tries quality levels and keeps close to the highest one that fits under your target. If even the lowest quality (10%) is too big, it makes the picture smaller in pixels and tries again.</li>
    <li><b>PNG.</b> PNG has no quality setting, so the tool can only reduce the size in pixels until the file fits. For a photo, choose JPG or WebP as the output for a far better result.</li>
    <li><b>Already under the target?</b> If you keep the original format and size and the file is already small enough, you get your original back unchanged.</li>
    <li><b>Resize first.</b> Any resize option you set is applied before the target is reached.</li>
    <li><b>If it cannot fit.</b> A file that stays above the target is marked "above target" with a red message. Try a larger target or resize the image smaller first.</li>
  </ul>
  <p>The After preview shows the final size in pixels, so you can see when the image had to be reduced to meet a small target. Very small targets on large, detailed photos will look soft.</p>

  <h2>Lossy or lossless: will quality suffer?</h2>
  <p>JPG and WebP are lossy. They throw away detail the eye barely notices, which is how the files get so much smaller. At 75% to 85% the difference is hard to see, while at much lower settings blockiness and blur start to show. PNG is lossless, so every pixel is kept, but it saves far less space. Compare the Before and After previews before you download.</p>

  <h2>Compress images for websites, email and forms</h2>
  <ul>
    <li><b>Websites.</b> Smaller images load faster. WebP or JPG at 75% to 80%, resized to the width the page really shows, is a solid choice.</li>
    <li><b>Email and messaging.</b> Resize to about 1600 pixels wide and use JPG at 75% to 80%, or pick a target such as 500 KB or 1 MB.</li>
    <li><b>Online forms and ID photos.</b> If a portal asks for a file under 100 KB or 200 KB, use Target file size and then check the pixel size the form requires.</li>
  </ul>

  """
rep("<h2>Tips for better results</h2>", NEW_PROSE + "<h2>Tips for better results</h2>", "prose")

rep('<a href="../imageconverter/">Image Converter</a>, <a href="../pngtojpg/">PNG to JPG</a> and <a href="../jpgtowebp/">JPG to WebP</a> convert without resizing.',
    '<a href="../imageconverter/">Image Converter</a>, <a href="../pngtojpg/">PNG to JPG</a>, <a href="../jpgtopng/">JPG to PNG</a>, <a href="../jpgtowebp/">JPG to WebP</a> and <a href="../webptojpg/">WebP to JPG</a> convert without resizing.',
    "tips links")

# ---------- 6) FAQ: visible list + JSON-LD from the same data ----------
NEW_FAQ = [
 ("How do I compress an image online?",
  "Add your JPG, PNG or WebP image. Choose the output format, then compress by quality level or by target file size, and the result appears automatically. Check the size saved, then download the compressed image."),
 ("Is this image compressor free, and does it add a watermark?",
  "Yes, it is free. There is no sign-up and no watermark, and the tool sets no limit on how many images you add. Very large batches depend on your device's memory."),
 ("How do I compress an image to 100KB?",
  "Set Compress by to Target file size, choose 100 KB and add your image. The tool lowers the quality, and the size in pixels if needed, until the file fits under 100 KB."),
 ("Can I compress an image to 50KB, 200KB or 1MB?",
  "Yes. Presets run from 20 KB to 2 MB, and Custom lets you enter any size in KB or MB. Very small targets may need a much lower quality or a smaller image."),
 ("What if the tool cannot reach my target size?",
  "The file is marked \"above target\" and a message names it. Try a larger target, resize the image smaller first, or choose JPG or WebP as the output format."),
 ("Can I compress an image without losing quality?",
  "JPG and WebP are lossy, but at 75% to 85% quality the difference is usually hard to see. For no loss at all, choose PNG output, which keeps every pixel but gives much smaller savings."),
 ("Does compressing an image reduce its quality?",
  "With JPG and WebP, a little detail is removed to make the file smaller, and the lower the quality the more you may notice. Use the Before and After previews to find the lowest setting that still looks right."),
 ("Will compression change my image dimensions?",
  "Not by default: the width and height stay the same unless you choose a resize option. With Target file size, the pixel size is reduced only when lowering quality is not enough, or for PNG, which has no quality setting."),
 ("Why is my PNG not getting smaller?",
  "PNG is lossless, so it cannot be squeezed as much as JPG or WebP. Resize the image, switch the output to WebP or JPG, or use Target file size for a much smaller file."),
]
LAST_FAQ = "<details><summary>Does it work on a phone?</summary><p>Yes, in any modern browser. Big batches of large photos are easier on a computer, because processing uses your device's memory.</p></details>"
faq_html = "\n".join(
    f"  <details><summary>{html.escape(q, quote=False)}</summary><p>{html.escape(a, quote=False)}</p></details>"
    for q, a in NEW_FAQ)
rep(LAST_FAQ, LAST_FAQ + "\n" + faq_html, "faq html")

m = re.search(r'(<script type="application/ld\+json">)(.*?)(</script>)', s, re.S)
if not m:
    raise SystemExit("STOP [schema]: JSON-LD block not found. Nothing was changed.")
data = json.loads(m.group(2))
faq = next(n for n in data["@graph"] if n["@type"] == "FAQPage")
faq["mainEntity"] += [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in NEW_FAQ]
s = s[:m.start(2)] + json.dumps(data, ensure_ascii=False) + s[m.end(2):]

# ---------- 7) Related tools: swap QR Code + MP4 to GIF for image tools ----------
CARD_WEBP = '<a class="rt-card" href="../jpgtowebp/"><span class="rt-icon">⇄</span><h3>JPG to WebP</h3><p>Convert JPG images to WebP, which is usually smaller at the same visual quality.</p><span class="go">Convert image →</span></a>'
CARD_HEIC = '<a class="rt-card" href="../heictojpg/"><span class="rt-icon">▣</span><h3>HEIC to JPG</h3><p>Convert iPhone HEIC photos to JPG, then compress them here.</p><span class="go">Convert photo →</span></a>'
for href, card in (("qrcodegenerator", CARD_WEBP), ("mp4togif", CARD_HEIC)):
    s, n = re.subn(r'<a class="rt-card" href="\.\./' + href + r'/">.*?</a>', lambda _m, c=card: c, s, count=1, flags=re.S)
    if n != 1:
        raise SystemExit(f"STOP [related {href}]: card not found. Nothing was changed.")

vis = s.count("<details><summary>")
sch = len(json.loads(re.search(r'<script type="application/ld\+json">(.*?)</script>', s, re.S).group(1))["@graph"][2]["mainEntity"])
assert vis == sch, f"FAQ mismatch: {vis} visible vs {sch} in schema"

P.write_text(s, encoding="utf-8")
print(f"OK. FAQ items: {vis} (visible = schema). Backup: /tmp/imagecompressor.bak.html")
