#!/bin/bash
set -e
cd "$(dirname "$0")"
cd /workspaces/ConvertKit-Lite
B="$OLDPWD"
python3 "$B/apply_imagecompressor.py" tools/imagecompressor/index.html
cp -r "$B/tools/." tools/
git status --short
git add -A tools/
git commit -m "SEO: Image Compressor target size, Image to Excel upgrade, internal links"
git pull --rebase origin main && git push
echo DONE
